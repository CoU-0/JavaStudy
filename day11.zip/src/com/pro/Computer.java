package com.pro;

public class Computer extends Product {

	public Computer() {
		super(200);
	}
	
	@Override 
	public String toString() {
		return "compter";
	}
	
}
