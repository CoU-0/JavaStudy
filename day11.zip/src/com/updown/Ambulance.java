package com.updown;

public class Ambulance {

	void siren( ) {
		System.out.println("siren ~~~~~~~~~");
	}
	
	

}
