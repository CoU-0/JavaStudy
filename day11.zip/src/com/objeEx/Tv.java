package com.objeEx;

public class Tv {

	boolean power ; // 온 오프로 활용 
	int channel; // 채널 
	
	//매소드 
	void power() {power = !power;} 
	void channelUp() {++channel;}
	void channelDown() {--channel;}
	
	
	
	
}
