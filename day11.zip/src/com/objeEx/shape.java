package com.objeEx;

public class shape { // 클래스 

String color = "black";

void draw () {
	System.out.printf("[color =%s]%n",color);
	
	
}


}
