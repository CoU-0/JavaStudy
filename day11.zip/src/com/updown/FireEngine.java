package com.updown;

public class FireEngine extends Car{

	void water( ) { // 물뿌리는 기능 
		System.out.println("water");
	}
	
}
