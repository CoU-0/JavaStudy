package com.objeEx;


public class Cellphone { // 부모클래스 

	String model; // 기종 
	String number; //전화번호
	int chord; // 벨소리
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}

	public void setNumber(String number) {
		this.number = number;
	}
	

	public void setChord(int chord) {
		this.chord = chord;
	}
	
	
	
	
	
	
	
}
