package com.updown;

public class Car {

	
	String color;
	int door; 
	
	void drive() { //운전기능 
	 System.out.println("drive, brrrrrr ~~~~");
		
	}
	
	void stop() {
		System.out.println("stop");
	}
}
